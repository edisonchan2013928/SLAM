#include "init_visual.h"

void initArray(double**& featureArray, int n, int dim)
{
	featureArray = new double*[n];
	for (int i = 0; i < n; i++)
		featureArray[i] = new double[dim];

	//initalization of featureArray
	for (int i = 0; i < n; i++)
		for (int d = 0; d < dim; d++)
			featureArray[i][d] = 0;
}

void initStat(double gamma, int n_row, int n_col, double row_L, double row_U, double col_L, double col_U, statistics& stat)
{
	//stat.alpha = alpha;
	stat.gamma = gamma;
	stat.n_row = n_row;
	stat.n_col = n_col;
	stat.row_L = row_L;
	stat.row_U = row_U;
	stat.col_L = col_L;
	stat.col_U = col_U;
	//stat.q_type = q_type;
	/*stat.method = method;
	stat.leafCapacity = leafCapacity;
	stat.leafCapacity_Query = leafCapacity_Query;*/

	if (n_row != 1 || n_col != 1)
	{
		stat.incr_row = (row_U - row_L) / (n_row - 1);
		stat.incr_col = (col_U - col_L) / (n_col - 1);
	}	

	if (n_row == 1)
		stat.incr_row = 0;
	if (n_col == 1)
		stat.incr_col = 0;

	stat.out_matrix = new double*[n_row];
	for (int i = 0; i < n_row; i++)
		stat.out_matrix[i] = new double[n_col];

	stat.out_vector = new double[n_row*n_col];

	//for (int t = 0; t < (int) stat.tau_List.size(); t++)
	//	stat.tau_List.push_back(tau_List[t]);
}

void loadRegion(char*regionFileName, double& row_L, double& row_U, double& col_L, double& col_U)
{
	fstream regionFile;

	regionFile.open(regionFileName);

	if (regionFile.is_open() == false)
	{
		cout << "Cannot open region file!" << endl;
		exit(0);
	}

	regionFile >> row_L;
	regionFile >> row_U;
	regionFile >> col_L;
	regionFile >> col_U;

	regionFile.close();
}

void updateRegion(double** featureArray,int n, double& row_L, double& row_U, double& col_L, double& col_U)
{
	row_L = inf;
	row_U = -inf;
	col_L = inf;
	col_U = -inf;

	for (int i = 0; i < n; i++)
	{
		if (featureArray[i][0] < row_L)
			row_L = featureArray[i][0];
		if (featureArray[i][0] > row_U)
			row_U = featureArray[i][0];

		if (featureArray[i][1] < col_L)
			col_L = featureArray[i][1];
		if (featureArray[i][1] > col_U)
			col_U = featureArray[i][1];
	}
}

void init_tauList(char*tau_List_FileName, vector<double>& tau_List)
{
	fstream tau_List_File;
	int tau_number;
	double tau_value;

	tau_List_File.open(tau_List_FileName);

	if (tau_List_File.is_open() == false)
	{
		cout << "Cannot open tau_List File!" << endl;
		exit(0);
	}

	tau_List_File >> tau_number;

	for (int t = 0; t < tau_number; t++)
	{
		tau_List_File >> tau_value;
		tau_List.push_back(tau_value);
	}
}

//void obtain_bandwidth(double**featureArray,int n, double& h0, double& h1,double b)
void preprocessData(double**featureArray, int n, double& h0, double& h1, double b)
{
	double sigma_0, sigma_1;
	double sum_X0, sum_X1;
	double mean_X0, mean_X1;
	double sum_square_X0, sum_square_X1;
	double sqrt_h0;
	double sqrt_h1;

	sum_X0 = 0; sum_X1 = 0;
	sum_square_X0 = 0, sum_square_X1 = 0;

	for (int i = 0; i < n; i++)
	{
		sum_X0 += featureArray[i][0];
		sum_X1 += featureArray[i][1];

		sum_square_X0 += featureArray[i][0] * featureArray[i][0];
		sum_square_X1 += featureArray[i][1] * featureArray[i][1];
	}

	mean_X0 = sum_X0 / (double)n;
	mean_X1 = sum_X1 / (double)n;

	sigma_0 = sqrt((sum_square_X0 - n * mean_X0*mean_X0) / ((double)n));
	sigma_1 = sqrt((sum_square_X1 - n * mean_X1*mean_X1) / ((double)n));

	h0 = b * pow((double)n, -1 / 6.0)*sigma_0;
	h1 = b * pow((double)n, -1 / 6.0)*sigma_1;

	sqrt_h0 = sqrt(2 * h0);
	sqrt_h1 = sqrt(2 * h1);
	for (int i = 0; i < n; i++)
	{
		featureArray[i][0] /= sqrt_h0;
		featureArray[i][1] /= sqrt_h1;
	}
}

void obtain_alpha(double h0, double h1, int n , double& alpha)
{
	double pi = 3.14159265359;
	alpha = 1 / (2 * pi*sqrt(h0*h1)*n);
}

void extract_FeatureVector(char*fileName, statistics& stat, double**& featureArray)
{
	//load data to feature array
	fstream file;
	int n;
	int dim;

	file.open(fileName);
	if (file.is_open() == false)
	{
		cout << "Cannot Open File!" << endl;
		exit(1);
	}

	file >> n;
	file >> dim;

	stat.n = n;
	if (stat.dim != dim)
	{
		cout << "dimension is not matched!" << endl;
		exit(0);
	}

	featureArray = new double*[n];
	for (int i = 0; i < n; i++)
		featureArray[i] = new double[dim];

	for (int i = 0; i < n; i++)
		for (int d = 0; d < dim; d++)
			file >> featureArray[i][d];

	file.close();
}

void saveMatrix_toFile(char*fileName, statistics& stat)
{
	fstream file;
	file.open(fileName, ios::in | ios::out | ios::trunc);
	if (file.is_open() == false)
	{
		cout << "Cannot Open Files!" << endl;
		return;
	}

	for (int i = 0; i < stat.n_row; i++)
	{
		for (int j = 0; j < stat.n_col; j++)
			file << stat.out_matrix[i][j] << " ";
		file << endl;
	}

	file.close();
}

void vectorized_preprocess(double**& queryVector, statistics& stat)
{
	double i_coord;
	double j_coord;

	double sqrt_h0;
	double sqrt_h1;

	//(1) obtain back all regions
	queryVector = new double*[stat.n_row*stat.n_col];
	for (int q = 0; q < stat.n_row*stat.n_col; q++)
		queryVector[q] = new double[2];

	sqrt_h0 = sqrt(2 * stat.h0);
	sqrt_h1 = sqrt(2 * stat.h1);
	for (int i = 0; i < stat.n_row; i++)
	{
		i_coord = (stat.row_L + i * stat.incr_row) / sqrt_h0;
		for (int j = 0; j < stat.n_col; j++)
		{
			j_coord = (stat.col_L + j * stat.incr_col) / sqrt_h1;
			queryVector[i*stat.n_col + j][0] = i_coord; //transform query in 1st coord
			queryVector[i*stat.n_col + j][1] = j_coord; //transform query in 2nd coord
		}
	}
}

void queries_preprocess(double**& queryVector, spatial_pos**& queryMatrix, statistics& stat,int method_Qset)
{
	double i_coord;
	double j_coord;

	double sqrt_h0;
	double sqrt_h1;

	//(1) obtain back all regions
	queryVector = new double*[stat.n_row*stat.n_col];
	for (int q = 0; q < stat.n_row*stat.n_col; q++)
		queryVector[q] = new double[2];

	if (method_Qset == 2)
	{
		queryMatrix = new spatial_pos*[stat.n_row];
		for (int i = 0; i < stat.n_row; i++)
			queryMatrix[i] = new spatial_pos[stat.n_col];
	}

	sqrt_h0 = sqrt(2 * stat.h0);
	sqrt_h1 = sqrt(2 * stat.h1);
	for (int i = 0; i < stat.n_row; i++)
	{
		i_coord = (stat.row_L + i * stat.incr_row) / sqrt_h0;
		for (int j = 0; j < stat.n_col; j++)
		{
			j_coord = (stat.col_L + j * stat.incr_col) / sqrt_h1;

			if (method_Qset == 1) //vectorized_preprocess
			{
				queryVector[i*stat.n_col + j][0] = i_coord; //transform query in 1st coord
				queryVector[i*stat.n_col + j][1] = j_coord; //transform query in 2nd coord
			}
			if (method_Qset == 2) //consider its spatial relationship
			{
				queryVector[i*stat.n_col + j][0] = i_coord; //transform query in 1st coord
				queryVector[i*stat.n_col + j][1] = j_coord; //transform query in 2nd coord
				queryMatrix[i][j].i_coord = i_coord;
				queryMatrix[i][j].j_coord = j_coord;
			}
		}
	}
}

void queries_preprocess(double**& queryVector, statistics& stat)
{
	double i_coord;
	double j_coord;

	double sqrt_h0;
	double sqrt_h1;

	//(1) obtain back all regions
	queryVector = new double*[stat.n_row*stat.n_col];
	for (int q = 0; q < stat.n_row*stat.n_col; q++)
		queryVector[q] = new double[2];

	sqrt_h0 = sqrt(2 * stat.h0);
	sqrt_h1 = sqrt(2 * stat.h1);
	for (int i = 0; i < stat.n_row; i++)
	{
		i_coord = (stat.row_L + i * stat.incr_row) / sqrt_h0;
		for (int j = 0; j < stat.n_col; j++)
		{
			j_coord = (stat.col_L + j * stat.incr_col) / sqrt_h1;

			queryVector[i*stat.n_col + j][0] = i_coord; //transform query in 1st coord
			queryVector[i*stat.n_col + j][1] = j_coord; //transform query in 2nd coord
		}
	}
}

void outVec_2_outMatrix(statistics& stat)
{
	for (int r = 0; r < stat.n_row; r++)
		for (int c = 0; c < stat.n_col; c++)
			stat.out_matrix[r][c] = stat.out_vector[r*stat.n_col + c];
}

void init_outVec(statistics& stat)
{
	for (int q = 0; q < stat.n_row*stat.n_col; q++)
		stat.out_vector[q]=-1;
}

void output_sample_dataset(char*output_sample_fileName, double** sampleVector, int sample_n)
{
	fstream output_sample_file;

	output_sample_file.open(output_sample_fileName, ios::in | ios::out | ios::trunc);
	if (output_sample_file.is_open() == false)
	{
		cout << "Cannot open output sample file!" << endl;
		exit(0);
	}

	output_sample_file << sample_n << " 2" << endl;

	for (int i = 0; i < sample_n; i++)
		output_sample_file << sampleVector[i][0] << " " << sampleVector[i][1] << endl;

	output_sample_file.close();
}

//bug_testing
void outputArray(double**featureArray, int n, int dim)
{
	for (int i = 0; i < n; i++)
	{
		for (int d = 0; d < dim; d++)
			cout << featureArray[i][d] << " ";
		cout << endl;
	}
}
#include "sampling.h"

void random_sampling(double**featureVector, double**& sampleVector, statistics& stat)
{
	vector<int> random_List;
	srand(time(NULL));
	int number_of_samples;
	double prob = 0.001;

	for (int i = 0; i < stat.n; i++)
		random_List.push_back(i);

	random_shuffle(random_List.begin(), random_List.end());

	number_of_samples = (int)((1 / (stat.epsilon*stat.epsilon)) * log(1 / prob));

	sampleVector = new double*[number_of_samples];
	for (int i = 0; i < number_of_samples; i++)
		sampleVector[i] = new double[stat.dim];

	for (int i = 0; i < number_of_samples; i++)
	{
		for (int d = 0; d < stat.dim; d++)
			sampleVector[i][d] = featureVector[random_List[i]][d];
	}

	stat.alpha = ((double)stat.n / (double)number_of_samples);
	stat.n = number_of_samples;
}

void sequential_sampling(double**featureVector, double**& sampleVector, statistics& stat)
{
	int number_of_samples;
	int index;

	number_of_samples = (int)((1 / stat.epsilon) * log((double)stat.n) / log(2.0)
		* pow(log(1.0 / stat.epsilon) / log(2.0), 1.5));

	sampleVector = new double*[number_of_samples];
	for (int i = 0; i < number_of_samples; i++)
		sampleVector[i] = new double[stat.dim];

	for (int s = 0; s < number_of_samples; s++)
	{
		if (s != number_of_samples - 1)
			index = (int)ceil((s + 1 / 2.0)*((double)stat.n / number_of_samples));
		else
			index = stat.n - 1;

		for (int d = 0; d < stat.dim; d++)
			sampleVector[s][d] = featureVector[index][d];
	}

	stat.alpha = ((double)stat.n / (double)number_of_samples);
	stat.n = number_of_samples;
}

void data_sampling(double**featureVector, double**& sampleVector, statistics& stat, int method)
{
	double sampling_time;
	vector<z_order_entry> z_order_List;
	stat.epsilon = 0.001;

	auto start_s = chrono::high_resolution_clock::now();

	if (method == 1) //random sampling
		random_sampling(featureVector, sampleVector, stat);
	if (method == 2) //Z-order +sampling
	{
		int**featureVector_INT;
		INT_transform(featureVector, featureVector_INT, stat.n, stat.scale);
		obtain_Z_order(featureVector_INT, z_order_List, stat.n);
		sort_dataset(featureVector, z_order_List, stat.n);
		sequential_sampling(featureVector, sampleVector, stat);
	}

	auto end_s = chrono::high_resolution_clock::now();

	sampling_time = (chrono::duration_cast<chrono::nanoseconds>(end_s - start_s).count()) / 1000000000.0;

	cout << "sampling method " << method << ":" << sampling_time << endl;
}
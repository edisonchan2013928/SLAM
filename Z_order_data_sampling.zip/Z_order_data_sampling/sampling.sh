g++ -c init_visual.cpp -w -o init_visual.o
g++ -c z_order.cpp -w -o z_order.o
g++ -c sampling.cpp -w -o sampling.o
g++ main.cpp -O3 -o main init_visual.o z_order.o sampling.o

#char*dataFileName = (char*)argv[1];
#char*sampleFileName = (char*)argv[2];
#int sample_method = atoi(argv[3]);

dir="../Datasets/"
dataset="Seattle"
sample_dataset="Seattle_sample"
sample_method=2 #method = 2: Z-order method

./main $dir$dataset"/"$dataset $dir$dataset"/"$sample_dataset $sample_method
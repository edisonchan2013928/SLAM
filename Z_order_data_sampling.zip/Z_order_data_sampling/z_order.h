#ifndef Z_ORDER_H
#define Z_ORDER_H

#include "init_visual.h"

struct z_order_entry
{
	int index;
	unsigned long long z_order_value;

	bool operator<(z_order_entry& entry)
	{
		return z_order_value < entry.z_order_value;
	}
};

unsigned long long interleave(int x, int y);
void obtain_Z_order(int**dataset_INT, vector<z_order_entry>& z_order_List, int n);
void INT_transform(double**dataset, int**& dataset_INT, int n, double scale);
void sort_dataset(double**dataset, vector<z_order_entry>& z_order_List, int n);

#endif
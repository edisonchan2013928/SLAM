#include "z_order.h"

/*bool z_order_value_compare(z_order_entry& entry1, z_order_entry& entry2)
{
	return entry1.z_order_value < entry2.z_order_value;
}*/

unsigned long long interleave(int x, int y)
{
	bitset<sizeof(int) * 8> bit_x(x);
	bitset<sizeof(int) * 8> bit_y(y);
	bitset<sizeof(long long) * 8> bit_z;

	for (int b = 0; b < 32; b++)
	{
		bit_z[2 * b] = bit_x[b];
		bit_z[2 * b + 1] = bit_y[b];
	}

	return bit_z.to_ullong();
}

void obtain_Z_order(int**dataset_INT, vector<z_order_entry>& z_order_List, int n)
{
	z_order_entry entry;
	for (int i = 0; i < n; i++)
	{
		entry.index = i;
		entry.z_order_value = interleave(dataset_INT[i][0], dataset_INT[i][1]);
		z_order_List.push_back(entry);
	}

	for (int i = 0; i < n; i++)
		delete[] dataset_INT[i];
	delete[] dataset_INT;
}

void INT_transform(double**dataset, int**& dataset_INT, int n, double scale)
{
	double x_min = inf;
	double y_min = inf;

	dataset_INT = new int*[n];
	for (int i = 0; i < n; i++)
		dataset_INT[i] = new int[2];

	for (int i = 0; i < n; i++)
	{
		if (dataset[i][0] < x_min)
			x_min = dataset[i][0];

		if (dataset[i][1] < y_min)
			y_min = dataset[i][1];
	}

	if (x_min > 0)
		x_min = 0;
	if (y_min > 0)
		y_min = 0;

	for (int i = 0; i < n; i++)
	{
		dataset_INT[i][0] = (int)((dataset[i][0] - x_min)*scale);
		dataset_INT[i][1] = (int)((dataset[i][1] - y_min)*scale);
	}
}

void sort_dataset(double**dataset, vector<z_order_entry>& z_order_List, int n)
{
	double**dataset_sorted;
	dataset_sorted = new double*[n];
	for (int i = 0; i < n; i++)
		dataset_sorted[i] = new double[2];

	//sort(z_order_List.begin(),z_order_List.end(), z_order_value_compare);
	sort(z_order_List.begin(), z_order_List.end());

	for (int i = 0; i < n; i++)
		for (int d = 0; d < 2; d++)
			dataset_sorted[i][d] = dataset[z_order_List[i].index][d];

	for (int i = 0; i < n; i++)
		for (int d = 0; d < 2; d++)
			dataset[i][d] = dataset_sorted[i][d];

	for (int i = 0; i < n; i++)
		delete[] dataset_sorted[i];
	delete[] dataset_sorted;
}
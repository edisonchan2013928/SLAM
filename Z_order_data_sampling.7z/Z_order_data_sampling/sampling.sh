#Compile the code
g++ -c init_visual.cpp -w -o init_visual.o
g++ -c z_order.cpp -w -o z_order.o
g++ -c sampling.cpp -w -o sampling.o
g++ main.cpp -O3 -o main init_visual.o z_order.o sampling.o
exit

#Please remove the above word "exit" to run the code in order to obtain the sampled dataset.
#char*dataFileName = (char*)argv[1]; #This is the input data file name.
#char*sampleFileName = (char*)argv[2]; #This is the output file name for sampled dataset.
#int sample_method = atoi(argv[3]); #method = 2 denotes the Z-order method.

dir="../Datasets/"
dataset="Seattle"
sample_dataset="Seattle_sample"
sample_method=2 #method = 2: Z-order method

./main $dir$dataset"/"$dataset $dir$dataset"/"$sample_dataset $sample_method
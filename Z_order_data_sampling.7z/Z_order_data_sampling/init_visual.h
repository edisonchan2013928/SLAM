#pragma once

#ifndef INIT_VISUAL_H
#define INIT_VISUAL_H

#include "Library.h"
//#include "Grid.h"

const double inf = 999999999999;
const double small_epsilon = 0.000000000000001;
const double pi = 3.14159265359;

struct Grid
{
	double**Q_boundary;
	int row_id_left;
	int row_id_right;
	int col_id_left;
	int col_id_right;
};

struct spatial_pos
{
	double i_coord;
	double j_coord;
};

struct bound_pair
{
	double lb;
	double ub;
};

struct statistics
{
	int n; //number of points in datasets
	double**out_matrix; //act as the output matrix for both T-KVQ and epsilon-KVQ
	double*out_vector; //act as the output vector for both T-KVQ and epsilon-KVQ
	double alpha; //weight alpha
	double gamma; //gamma coefficient
	int n_row; //number of discrete region in the row, e.g. 100
	int n_col; //number of discrete region in the col, e.g. 100
	double row_L,row_U; //row region, e.g. [-2,2]
	double col_L,col_U; //col region e.g. [-2,2]
	double incr_row; //incremental row e.g. (2-(-2))/100=0.04
	double incr_col; //incremental col e.g. (2-(-2))/100=0.04
	int leafCapacity; //leaf capacity for the P set
	int leafCapacity_Query; //leaf capaacity for the Q set

	double h0, h1; //bandwidth

	const int dim = 2; //dim = 2 (2d visualization)
	
	int q_type; //q_type=0: epsilon-KVQ q_type=1: tau-KVQ
	vector<double> tau_List; //thresholds used for T-KVQ
	double tau_binary; //theshold used for T-KVQ (binary setting)
	double epsilon; //epsilon value for epsilon-KVQ

	int method; //chosen method

	int kernel_type; //0: Gaussian kernel, 1: Triangular kernel 2:Cosine kernel 3:Exponential kernel 

	//Single query setting: Used in methods SCAN, tKDC and KARL (method=0,1,2) 
	double*q;
	int out_i;
	int out_j;
	int out_id;

	//Used in Dual-tree BFS
	double**Q_boundary;
	vector<int>*idList_Ptr;
	bool Q_filter;

	//Used in online stage for KARL
	double qSquareNorm;

	//Grid setting: Used in methods tKDC-Grid and KARL-Grid (method=3,4)
	double**queryVector;
	Grid*grid_ptr;

	//Used in sequential grid algorithm 
	int row_blocks; //number of blocks in row
	int col_blocks; //number of blocks in col

	double scale; //Used in Z-order based data sampling
};

void initArray(double**& featureArray, int n, int dim);
//void initStat(double alpha, double gamma, int n_row, int n_col, double row_L, double row_U, double col_L, double col_U, int q_type, vector<double>& tau_List, statistics& stat, int method, int leafCapacity, int leafCapacity_Query);
void initStat(double gamma, int n_row, int n_col, double row_L, double row_U, double col_L, double col_U, statistics& stat);
void loadRegion(char*regionFileNamedouble, double& row_L, double& row_U, double& col_L, double& col_U);
void updateRegion(double** featureArray, int n, double& row_L, double& row_U, double& col_L, double& col_U);
void init_tauList(char*tau_List_FileName, vector<double>& tau_List);
void preprocessData(double**featureArray, int n, double& h0, double& h1, double b);
void obtain_alpha(double h0, double h1, int n, double& alpha);
void extract_FeatureVector(char*fileName,statistics& stat, double**& featureArray);
void saveMatrix_toFile(char*fileName, statistics& stat);

//vectorized the 2d queryMatrix to 1d queryVector
void vectorized_preprocess(double**& queryVector, statistics& stat);
void queries_preprocess(double**& queryVector, spatial_pos**& queryMatrix, statistics& stat, int method_Qset);
void queries_preprocess(double**& queryVector, statistics& stat);

void outVec_2_outMatrix(statistics& stat);

//init outVec to -1 (Used in GBF_iter_dual)
void init_outVec(statistics& stat);

//Use this function to output the sample dataset
void output_sample_dataset(char*output_sample_fileName, double** sampleVector, int sample_n);

//bug_testing
void outputArray(double**featureArray, int n, int dim);

#endif
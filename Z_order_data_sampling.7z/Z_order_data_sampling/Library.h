#ifndef LIBRARY_H
#define LIBRARY_H

#include <iostream>
#include <fstream>
#include <string> //Windows 
#include <string.h> //Linux
#include <vector>
#include <cmath>
#include <algorithm>
#include <queue>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits>
#include <sstream>
#include <chrono>
#include <bitset>

//#define C_PLUSPLUS11_CLOCK
/*#ifdef C_PLUSPLUS11_CLOCK
#include <chrono>
#endif*/

using namespace std;

#endif
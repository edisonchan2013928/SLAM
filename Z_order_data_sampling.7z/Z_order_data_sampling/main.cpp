#include "sampling.h"

int main(int argc, char**argv)
{
	statistics stat;
	double**featureVector;
	double**sampleVector;

	char*dataFileName = (char*)argv[1];
	char*sampleFileName = (char*)argv[2];
	int sample_method = atoi(argv[3]);

	/*char*dataFileName = (char*)"../../../Datasets/Seattle/Seattle";
	char*sampleFileName = (char*)"../../../Datasets/Seattle/Seattle_sample";
	int sample_method = 2;*/

	extract_FeatureVector(dataFileName, stat, featureVector);
	data_sampling(featureVector, sampleVector, stat, sample_method);
	output_sample_dataset(sampleFileName, sampleVector, stat.n);
}
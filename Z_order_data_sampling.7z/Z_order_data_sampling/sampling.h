#pragma once
#ifndef SAMPLING_H
#define SAMPLING_H

#include "init_visual.h"
#include "z_order.h"

//random sampling (method=1)
void random_sampling(double**featureVector, double**& sampleVector, statistics& stat);
void data_sampling(double**featureVector, double**& sampleVector, statistics& stat, int method);

#endif